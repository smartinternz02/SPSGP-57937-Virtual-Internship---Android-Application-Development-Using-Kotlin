package com.example.quotes.data

import com.example.quotes.R
import com.example.quotes.models.Quotes



class Datasource {

    fun loadquotes(): List<Quotes> {
        return listOf<Quotes>(
            Quotes(R.string.quotes1, R.drawable.image1),
            Quotes(R.string.quotes2, R.drawable.image2),
            Quotes(R.string.quotes3, R.drawable.image3),
            Quotes(R.string.quotes4, R.drawable.image4),
            Quotes(R.string.quotes5, R.drawable.image5),
            Quotes(R.string.quotes6, R.drawable.image6),
            Quotes(R.string.quotes7, R.drawable.image7),
            Quotes(R.string.quotes8, R.drawable.image8),
            Quotes(R.string.quotes9, R.drawable.image9),
            Quotes(R.string.quotes10, R.drawable.image10),

        )
    }
}